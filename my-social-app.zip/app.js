function addPost() {
  const input = document.getElementById("postInput");
  const postArea = document.getElementById("postArea");

  const post = document.createElement("div");
  post.innerText = input.value;
  postArea.appendChild(post);

  input.value = "";
}
